# JARVIS Online — Render deployment package

This package uses the supplied `index.html` design and adds a Node/Express OpenAI backend plus password-protected browser sessions. It is configured for Render as a single web service.

## Deploy on Render

1. Create a private GitHub repository named `jarvis-online`.
2. Upload the contents of this folder to the repository root (including `render.yaml`).
3. In Render, choose **New → Blueprint**, connect the GitHub repository, and apply the Blueprint.
4. In the Render service's Environment settings, fill in the three secret values:
   - `OPENAI_API_KEY`: your OpenAI API key
   - `JARVIS_ACCESS_PASSWORD`: create a strong, unique password of at least 14 characters
   - `SESSION_SECRET`: generate a random secret of at least 32 characters (for example, run `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"` locally)
5. Save and deploy. Render will provide an HTTPS `onrender.com` URL. Open it and sign in with your JARVIS access password.

## Security and operating notes

- The OpenAI key is only read by the server; it is never sent to the browser.
- JARVIS requires a password to access chat. Session cookies are HttpOnly, Secure in production, SameSite=Strict, and expire after 12 hours.
- Login and chat requests are rate limited; inputs are validated; Helmet security headers are enabled.
- Do not commit `.env` or secrets to GitHub. Enter secret values in Render's Environment settings.
- The Blueprint uses Render's Free plan as a starting point. Free web services can spin down after inactivity, so the first request after idle may be delayed. Choose a paid instance if you need consistently responsive availability.
- Conversation context remains in the current browser tab only. Persistent cross-device memory, account-specific user management, and smart-home/device control are not included yet.
- Speech recognition and the exact British voice depend on browser and operating-system support.

## Render settings

The Blueprint sets `npm install`, `npm start`, and `/api/health` as the health check. The server binds to `0.0.0.0` and uses Render's `PORT`.
