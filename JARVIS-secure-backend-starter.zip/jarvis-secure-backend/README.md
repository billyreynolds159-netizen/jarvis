# JARVIS Secure AI Backend — starter

This starter connects a browser-based JARVIS interface to OpenAI through a **server-side** Node.js API. The browser never receives the OpenAI API key.

## Requirements
- Node.js 20+
- An OpenAI API key with API billing/credits configured

## Run locally (Windows PowerShell)
1. Extract this folder.
2. Open PowerShell in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Open `.env` and set `OPENAI_API_KEY` to your secret key. Do not paste the key into `index.html`, browser JavaScript, GitHub, or chat.
6. Run `npm start`.
7. Open `http://localhost:3000`.

## Deploy
Deploy the Node app to a trusted HTTPS host. Set `OPENAI_API_KEY`, `OPENAI_MODEL`, `APP_ORIGIN`, and `PORT` as host environment variables. Set `APP_ORIGIN` to the exact origin serving your frontend. Never commit `.env`.

## Security included
- API key read only from server environment
- Helmet security headers
- Exact-origin CORS allowlist
- JSON body-size limit
- Per-IP request rate limit
- Input role, count, and length validation
- Generic browser-facing errors; provider details are not exposed
- No server-side conversation storage (`store: false`); this demo keeps recent conversation context in the browser tab only

## Before public launch
Add user authentication, per-user quotas, persistent encrypted memory with user controls, abuse monitoring, and a production rate-limit store. CORS is not authentication. Do not expose this endpoint publicly without access controls and budget limits. The demo's browser history is not durable memory.

## Existing prototype
The earlier `JARVIS.html` mentioned in the conversation is not present as an attachment in this workspace, so this starter includes a fresh sample dashboard. Its `/api/chat` call is the integration pattern to merge into the original dashboard.
